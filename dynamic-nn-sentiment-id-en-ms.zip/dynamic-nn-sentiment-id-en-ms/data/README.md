# Data

The datasets are public and are **not redistributed** here. The notebooks download them automatically (or read the 7 CSV files if you upload them).

| Language | Source | Notes |
|---|---|---|
| Indonesian, English | NusaX-senti, https://github.com/IndoNLP/nusax (`datasets/sentiment/{indonesian,english}`) | Parallel; neutral class removed (two classes) |
| Malay | Malay-Dataset, https://github.com/asrafulsyifaa/Malay-Dataset (`sentiment/news-sentiment/sentiment-data-v2.csv`) | Local News sentiment; 80:20 stratified split, 10% of train held out for validation |

Check each source repository for its licence and cite the original papers (NusaX: Winata et al., EACL 2023). Split sizes: Indonesian and English 381 / 76 / 304 (train / validation / test), Malay 2,644 / 294 / 735.
