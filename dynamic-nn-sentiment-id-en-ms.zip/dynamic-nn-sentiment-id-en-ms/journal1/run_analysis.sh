#!/bin/sh
# Reproduces every number and figure of Journal 1 from the raw results (no GPU needed).
# Usage: sh journal1/run_analysis.sh (from any folder)
set -e
cd "$(dirname "$0")/src"
python3 analyze_e1b.py ../results/raw/results_dynamic_A.json ../results/raw/latensi.csv ../results/raw/summary_dinamis.csv ../results/raw/ablasi_bobot.csv
mkdir -p ../results/figures/en && mv -f stats_j1.json ../results/stats_j1.json && mv -f img/*.png ../results/figures/en/ && rmdir img
# Indonesian-labelled figures (same statistics)
python3 analyze_e1b_figuras_id.py ../results/raw/results_dynamic_A.json ../results/raw/latensi.csv ../results/raw/summary_dinamis.csv ../results/raw/ablasi_bobot.csv
mkdir -p ../results/figures/id && mv -f img/*.png ../results/figures/id/ && rm -f stats_j1.json && rmdir img
rm -rf __pycache__
echo "Done: results/stats_j1.json and results/figures/{en,id}/"
