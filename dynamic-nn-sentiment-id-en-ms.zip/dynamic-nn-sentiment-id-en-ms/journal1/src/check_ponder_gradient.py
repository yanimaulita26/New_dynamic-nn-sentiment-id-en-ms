"""
check_ponder_gradient.py
Minimal replication of the halting/ponder accumulation used in the ACT model
(DynamicNN.forward, early-exit notebook). It checks whether the ponder-cost term
carries a gradient.

Result observed when run on Google Colab (torch):  ponder.requires_grad: False
Reason: `nup` is built only from `run.float()`, and `run` is a boolean mask updated by
comparisons, which are not differentiable. The ponder weight (tau) therefore has no
effect on training.
"""
import torch

bs = 4
p = torch.sigmoid(torch.randn(bs, requires_grad=True))   # stands in for per-layer halting probabilities
cum = torch.zeros(bs)
run = torch.ones(bs, dtype=torch.bool)
nup = torch.zeros(bs)
for l in range(12):
    newc = cum + p * run.float()
    halt = (newc >= 1.0 - 1e-3) | (l == 11)
    nup = nup + run.float()
    cum = torch.where(run, newc, cum)
    run = run & (~halt)
    if not run.any():
        break
ponder = nup.mean()
print("ponder.requires_grad:", ponder.requires_grad)
