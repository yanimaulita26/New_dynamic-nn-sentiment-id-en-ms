# ---- Sel: fungsi murni (numpy) -- tidak bergantung pada PyTorch ----
import numpy as np, pandas as pd

D_MODEL, N_BASE = 768, 12

def flops_layer(L):
    """FLOPs analitik satu layer encoder untuk L token: proyeksi QKV+O (8 L d^2), skor/konteks atensi (4 L^2 d), FFN (16 L d^2)."""
    L = np.asarray(L, float)
    return 24 * L * D_MODEL**2 + 4 * L**2 * D_MODEL

def rel_flops(layers_used, ntok):
    """FLOPs relatif terhadap komputasi penuh 12 layer, dibobot panjang token tiap teks."""
    f = flops_layer(ntok); lu = np.asarray(layers_used, float)
    return float((lu * f).sum() / (N_BASE * f).sum())

def norm_entropy(logits):
    z = logits - logits.max(-1, keepdims=True); p = np.exp(z); p /= p.sum(-1, keepdims=True)
    return -(p * np.log(p + 1e-12)).sum(-1) / np.log(logits.shape[-1])

def exit_entropy(U, theta):
    """U [K,n]. Layer keluar (1..K) = layer pertama dengan U<=theta; theta<0 berarti tidak pernah keluar dini."""
    K, n = U.shape
    if theta < 0: return np.full(n, K)
    ok = U <= theta
    return np.where(ok.any(0), ok.argmax(0) + 1, K)

def run_lengths(P):
    K, n = P.shape; r = np.ones((K, n), int)
    for l in range(1, K): r[l] = np.where(P[l] == P[l - 1], r[l - 1] + 1, 1)
    return r

def exit_patience(P, pat):
    K = P.shape[0]; ok = run_lengths(P) >= pat
    return np.where(ok.any(0), ok.argmax(0) + 1, K)

def act_offline(p, eps=1e-3):
    """p [K,n] probabilitas halting -> (N, alpha, R). Bobot alpha berjumlah 1 per teks; R = sisa (Graves)."""
    K, n = p.shape; cum = np.zeros(n); rem = np.ones(n); run = np.ones(n, bool)
    N = np.zeros(n); R = np.zeros(n); alpha = np.zeros((K, n))
    for l in range(K):
        runf = run.astype(float); newc = cum + p[l] * runf
        halt = (newc >= 1 - eps) | (l == K - 1); hr = halt & run
        alpha[l] = np.where(hr, rem, p[l] * runf); R = np.where(hr, rem, R); N += runf
        rem = np.where(run, rem - p[l], rem); cum = np.where(run, newc, cum); run = run & ~halt
    return N, alpha, R

def metrics(y, pred):
    y = np.asarray(y); pred = np.asarray(pred)
    def prf(c):
        tp = ((y == c) & (pred == c)).sum(); fp = ((y != c) & (pred == c)).sum(); fn = ((y == c) & (pred != c)).sum()
        p = tp / (tp + fp) if tp + fp else 0.0; r = tp / (tp + fn) if tp + fn else 0.0
        return p, r, (2 * p * r / (p + r) if p + r else 0.0)
    pn, rn, fn_ = prf(0); pp, rp, fp_ = prf(1)
    return {'acc': float((y == pred).mean()), 'f1': float((fn_ + fp_) / 2), 'rneg': float(rn), 'pneg': float(pn), 'rpos': float(rp)}

# ---- ringkasan: titik dipilih di VALIDASI, keberhasilan dinilai di UJI dengan interval berpasangan ----
def family(cname, ref_key):
    if cname.startswith('EEUent'): return 'EEu-entropi'
    if cname.startswith('EEUpat'): return 'EEu-patience'
    if cname.startswith('EEent'): return 'EE-entropi'
    if cname.startswith('EEpat'): return 'EE-patience'
    if cname.startswith('ACT'): return 'ACT'
    if cname.startswith('S') and cname != ref_key: return 'Statis-lebih-dangkal'
    return None

def select_point(ent, fam, tol_pts, ref_key='S12'):
    """Pilih konfigurasi keluarga `fam` pada satu seed: FLOPs terkecil dengan akurasi VALIDASI >= S12 - toleransi.
    Bila tidak ada yang memenuhi, kembali ke S12 sendiri (hemat 0)."""
    ref = ent[ref_key]['configs'][ref_key]; cands = []
    for key, e in ent.items():
        for cname, c in e['configs'].items():
            if family(cname, ref_key) == fam and c['val_acc'] >= ref['val_acc'] - tol_pts / 100:
                cands.append((c['rel_flops'], -c['val_acc'], cname, c))
    if not cands: return ref_key, ref
    b = min(cands, key=lambda t: (t[0], t[1])); return b[2], b[3]

def make_summary(results, max_loss_pts, min_saving, noninf_pts, B=2000, seed=0, ref_key='S12'):
    rng = np.random.default_rng(seed); rows = []
    for lang, d in results.items():
        if lang.startswith('_'): continue
        y = np.array(results['_meta'][lang]['y']); n = len(y)
        seeds = [s for s in sorted(d.keys(), key=int) if ref_key in d[s]]
        if not seeds: continue
        idx = rng.integers(0, n, size=(B, n))
        for fam in ['EE-entropi', 'EE-patience', 'EEu-entropi', 'EEu-patience', 'ACT', 'Statis-lebih-dangkal']:
            if not any(family(cn, ref_key) == fam for ent in d.values() for e in ent.values() for cn in e['configs']): continue
            sav, dtest, dvec = [], [], []
            for s in seeds:
                cname, c = select_point(d[s], fam, max_loss_pts, ref_key); ref = d[s][ref_key]['configs'][ref_key]
                sav.append(1 - c['rel_flops']); dtest.append((c['acc'] - ref['acc']) * 100)
                dvec.append((np.array(c['preds']) == y).astype(float) - (np.array(ref['preds']) == y).astype(float))
            dm = np.mean(dvec, axis=0); boots = dm[idx].mean(1) * 100
            sav = np.array(sav)
            lo, hi = np.percentile(boots, [2.5, 97.5])
            rows.append({'bahasa': lang, 'keluarga': fam, 'n_seed': len(seeds), 'hemat_FLOPs_rata2': float(sav.mean()),
                         'hemat_FLOPs_SD': float(sav.std(ddof=1)) if len(sav) > 1 else np.nan,
                         'selisih_akurasi_pts': float(np.mean(dtest)), 'CI95_bawah': float(lo), 'CI95_atas': float(hi),
                         'seed_memenuhi': int((sav >= min_saving).sum()),
                         'lolos': bool(sav.mean() >= min_saving and lo >= -noninf_pts)})
    return pd.DataFrame(rows)

def verdict(summary, min_langs=None):
    """Indonesia dan Inggris adalah terjemahan dari teks yang sama (bukan bukti independen). Lolos bila Melayu lolos DAN
    sedikitnya satu dari Indonesia/Inggris lolos."""
    if len(summary) == 0: return 0, 0, False
    dyn = summary[summary['keluarga'].isin(['EE-entropi', 'EE-patience', 'ACT'])]
    ok = dyn.groupby('bahasa')['lolos'].any().to_dict()
    passed = bool(ok.get('MS', False) and (ok.get('ID', False) or ok.get('EN', False)))
    return int(sum(ok.values())), len(ok), passed

def latency_table(results, ref_key='S12'):
    rows = []
    for lang, d in results.items():
        if lang.startswith('_'): continue
        agg = {}
        for s, ent in d.items():
            for key, e in ent.items():
                for cname, c in e['configs'].items():
                    if 'lat_ms' in c: agg.setdefault(cname, []).append((c['lat_ms'], c.get('agree', np.nan), c['rel_flops'], c['acc']))
        base = np.mean([x[0] for x in agg.get(ref_key, [])]) if ref_key in agg else np.nan
        for cname, v in sorted(agg.items()):
            lat = np.array([x[0] for x in v])
            rows.append({'bahasa': lang, 'konfigurasi': cname, 'n_seed': len(v), 'latensi_ms': lat.mean(), 'SD': lat.std(ddof=1) if len(v) > 1 else np.nan,
                         'rasio_vs_S12': lat.mean() / base if base == base else np.nan, 'FLOPs_rel': np.mean([x[2] for x in v]),
                         'akurasi': np.mean([x[3] for x in v]), 'kesepakatan_truncating_vs_offline': np.nanmean([x[1] for x in v])})
    return pd.DataFrame(rows)


# ---- ablasi bobot loss keluar (E1b) ----
def ee_prefix(key):
    """Awalan nama konfigurasi: EE (bobot linear, E1) atau EEU (bobot seragam, ablasi)."""
    return 'EEU' if key == 'EEu' else 'EE'

def weight_scheme(key):
    return 'uniform' if key == 'EEu' else 'linear'

def exit_weights(K, scheme):
    """Bobot loss tiap layer keluar: linear ~ l (kondisi E1) atau seragam 1/K (ablasi). Selalu berjumlah 1."""
    w = np.arange(1, K + 1, dtype=float) if scheme == 'linear' else np.ones(K)
    return w / w.sum()

def fixed_point_stat(results, lang, key, cname, ref=('S12', 'S12'), seeds=None, B=2000, seed=0):
    """Titik operasi TETAP (tanpa pemilihan): hemat FLOPs, akurasi, dan selisih terhadap ref dengan CI95 bootstrap berpasangan."""
    rng = np.random.default_rng(seed); y = np.array(results['_meta'][lang]['y']); n = len(y)
    seeds = seeds or [s for s in sorted(results[lang], key=int) if key in results[lang][s] and ref[0] in results[lang][s]]
    idx = rng.integers(0, n, size=(B, n))
    dv = np.mean([(np.array(results[lang][s][key]['configs'][cname]['preds']) == y).astype(float)
                  - (np.array(results[lang][s][ref[0]]['configs'][ref[1]]['preds']) == y).astype(float) for s in seeds], axis=0)
    b = dv[idx].mean(1) * 100; cf = [results[lang][s][key]['configs'][cname] for s in seeds]
    return {'n_seed': len(seeds), 'flops': float(np.mean([x['rel_flops'] for x in cf])), 'acc': float(np.mean([x['acc'] for x in cf])),
            'd': float(dv.mean() * 100), 'lo': float(np.percentile(b, 2.5)), 'hi': float(np.percentile(b, 97.5))}

def ablation_decision(results, lin=('EE', 'EEent_0.3'), uni=('EEu', 'EEUent_0.3'), min_gain=0.05, noninf=3.0):
    """Aturan keputusan (ditetapkan SEBELUM hasil terlihat): bobot seragam menggantikan bobot linear sebagai varian early exit untuk E2
    bila pada theta = 0.3 ia menghemat >= min_gain (poin proporsi) lebih banyak FLOPs DAN batas bawah CI95 selisih akurasi vs S12 >= -noninf,
    pada Melayu dan sedikitnya satu dari Indonesia/Inggris."""
    rows = []; ok = {}
    for lang in [l for l in results if not l.startswith('_')]:
        seeds = [s for s in sorted(results[lang], key=int) if lin[0] in results[lang][s] and uni[0] in results[lang][s] and 'S12' in results[lang][s]]
        if not seeds: continue
        a = fixed_point_stat(results, lang, *lin, seeds=seeds); u = fixed_point_stat(results, lang, *uni, seeds=seeds)
        gain = (1 - u['flops']) - (1 - a['flops']); ok[lang] = bool(gain >= min_gain and u['lo'] >= -noninf)
        rows.append({'bahasa': lang, 'n_seed': len(seeds), 'hemat_linear': 1 - a['flops'], 'hemat_seragam': 1 - u['flops'], 'tambahan_hemat': gain,
                     'akurasi_linear': a['acc'], 'akurasi_seragam': u['acc'], 'selisih_seragam_vs_S12': u['d'], 'CI95_bawah': u['lo'], 'CI95_atas': u['hi'], 'memenuhi': ok[lang]})
    use_uniform = bool(ok.get('MS', False) and (ok.get('ID', False) or ok.get('EN', False)))
    return pd.DataFrame(rows), ('SERAGAM' if use_uniform else 'LINEAR')
