"""Analisis E1 + E1b (5 seed, bobot linear dan seragam). Pemakaian: python analyze_e1b.py results_dynamic_A.json latensi.csv summary_dinamis.csv ablasi_bobot.csv
Keluaran: stats_j1.json, img/fig1.png (head per layer), img/fig2.png (Pareto). Membutuhkan core.py di folder yang sama."""
import sys, os, json
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
COMMA=FuncFormatter(lambda v,_: ('%g'%round(v,4)).replace('.',','))
def commafy(fig):
    for a in fig.axes:
        a.yaxis.set_major_formatter(COMMA)
        if a.get_xlabel().startswith('FLOPs'): a.xaxis.set_major_formatter(COMMA)

from core import *
RES, LAT, SUM, ABL = sys.argv[1:5]
R = json.load(open(RES)); L = ['ID', 'EN', 'MS']; seeds = sorted(R['ID'].keys(), key=int); rng = np.random.default_rng(0)
LN = {'ID': 'Indonesia', 'EN': 'Inggris', 'MS': 'Melayu'}; y = {l: np.array(R['_meta'][l]['y']) for l in L}; S = {'seeds': seeds}
def dmat(l, key, cn, ref=('S12', 'S12')):
    return np.array([(np.array(R[l][s][key]['configs'][cn]['preds']) == y[l]).astype(float) - (np.array(R[l][s][ref[0]]['configs'][ref[1]]['preds']) == y[l]).astype(float) for s in seeds])
def stat(l, key, cn, ref=('S12', 'S12'), B=2000, two=True):
    d = dmat(l, key, cn, ref); Sn, n = d.shape; it = d.mean(0); b1 = it[rng.integers(0, n, (B, n))].mean(1) * 100
    out = dict(d=float(d.mean() * 100), lo=float(np.percentile(b1, 2.5)), hi=float(np.percentile(b1, 97.5)), ps_min=float(d.mean(1).min() * 100), ps_max=float(d.mean(1).max() * 100))
    if two:
        b2 = np.empty(B)
        for b in range(B): b2[b] = d[rng.integers(0, Sn, Sn)][:, rng.integers(0, n, n)].mean()
        out.update(lo2=float(np.percentile(b2 * 100, 2.5)), hi2=float(np.percentile(b2 * 100, 97.5)))
    cf = [R[l][s][key]['configs'][cn] for s in seeds]
    out.update(flops=float(np.mean([c['rel_flops'] for c in cf])), acc=float(np.mean([c['acc'] for c in cf])), acc_sd=float(np.std([c['acc'] for c in cf], ddof=1)),
               rneg=float(np.mean([c['rneg'] for c in cf])), pneg=float(np.mean([c['pneg'] for c in cf]))); return out
PT = {'S12': ('S12', 'S12'), 'S4': ('S4', 'S4'), 'S6': ('S6', 'S6'), 'S8': ('S8', 'S8'), 'E03': ('EE', 'EEent_0.3'), 'E08': ('EE', 'EEent_0.8'), 'A01': ('ACT_0.1', 'ACT_0.1'), 'A10': ('ACT_1.0', 'ACT_1.0'),
      'P3': ('EE', 'EEpat_3'), 'P5': ('EE', 'EEpat_5'), 'U03': ('EEu', 'EEUent_0.3'), 'U08': ('EEu', 'EEUent_0.8')}
S['pt'] = {l: {k: stat(l, *v, two=(k not in ('S12', 'A10', 'P3'))) for k, v in PT.items()} for l in L}
S['vs'] = {l: {'E08_S6': stat(l, 'EE', 'EEent_0.8', ref=('S6', 'S6'), two=False), 'E03_S8': stat(l, 'EE', 'EEent_0.3', ref=('S8', 'S8'), two=False)} for l in L}
S['uvl'] = {l: {th: dict(stat(l, 'EEu', f'EEUent_{th}', ref=('EE', f'EEent_{th}'), two=False), sav_u=1 - float(np.mean([R[l][s]['EEu']['configs'][f'EEUent_{th}']['rel_flops'] for s in seeds])), sav_l=1 - float(np.mean([R[l][s]['EE']['configs'][f'EEent_{th}']['rel_flops'] for s in seeds]))) for th in ['0.3', '0.8']} for l in L}
S['head'] = {l: {k: {'acc': np.mean([R[l][s][k]['diag']['acc_per_layer'] for s in seeds], axis=0).tolist(), 'U': np.mean([R[l][s][k]['diag']['U_mean_per_layer'] for s in seeds], axis=0).tolist()} for k in ['EE', 'EEu']} for l in L}
S['act'] = {}
for l in L:
    for k in ['ACT_0.1', 'ACT_1.0']:
        h = np.mean([R[l][s][k]['diag']['N_hist'] for s in seeds], axis=0); N = np.arange(1, 13); S['act'][f'{l}|{k}'] = {'mean_layers': float(np.sum(h * N) / h.sum()), 'hist': (h / h.sum() * 100).tolist()}
lat = pd.read_csv(LAT); S['lat'] = {f"{r.bahasa}|{r.konfigurasi}": {'ms': r.latensi_ms, 'sd': (None if pd.isna(r.SD) else r.SD), 'ratio': r.rasio_vs_S12, 'flops': r.FLOPs_rel, 'n': int(r.n_seed)} for r in lat.itertuples()}
S['summary'] = pd.read_csv(SUM).to_dict('records'); S['abl'] = {r['bahasa']: r for r in pd.read_csv(ABL).to_dict('records')}; S['agree_min'] = float(lat['kesepakatan_truncating_vs_offline'].min())
S['s12'] = {l: {'per_seed': [R[l][s]['S12']['configs']['S12']['acc'] for s in seeds], 'mean': float(np.mean([R[l][s]['S12']['configs']['S12']['acc'] for s in seeds])), 'sd': float(np.std([R[l][s]['S12']['configs']['S12']['acc'] for s in seeds], ddof=1))} for l in L}
S['fallback'] = {l: sum(select_point(R[l][s], 'EE-entropi', 1.0)[0] == 'S12' for s in seeds) for l in L}
os.makedirs('img', exist_ok=True); json.dump(S, open('stats_j1.json', 'w'), indent=1)
fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.7)); yl = {'ID': (0.82, 0.915), 'EN': (0.84, 0.93), 'MS': (0.725, 0.815)}
for a, l in zip(ax, L):
    def agg(prefix, key):
        pts = {}
        for s in seeds:
            for cn, c in R[l][s][key]['configs'].items():
                if cn.startswith(prefix): pts.setdefault(cn, []).append((c['rel_flops'], c['acc']))
        return sorted([(np.mean([p[0] for p in v]), np.mean([p[1] for p in v]), cn) for cn, v in pts.items()])
    e = [p for p in agg('EEent', 'EE') if p[2] != 'EEent_1.0']; pa = agg('EEpat', 'EE'); eu = [p for p in agg('EEUent', 'EEu') if p[2] != 'EEUent_1.0']
    a.plot([p[0] for p in e], [p[1] for p in e], 'o-', ms=3, lw=1.2, color='#1f77b4', label='Keluar dini, entropi')
    a.plot([p[0] for p in eu], [p[1] for p in eu], 'o:', ms=2.5, lw=1.0, color='#ff7f0e', label='Keluar dini, entropi, bobot seragam')
    a.plot([p[0] for p in pa], [p[1] for p in pa], 's--', ms=3, lw=1.0, color='#2ca02c', label='Keluar dini, patience')
    for k in ['S4', 'S6', 'S8', 'S12']: p = S['pt'][l][k]; a.plot(p['flops'], p['acc'], 'D', color='black', ms=4); a.annotate(k, (p['flops'], p['acc']), fontsize=6, xytext=(2, 3), textcoords='offset points')
    p = S['pt'][l]['A01']; a.plot(p['flops'], p['acc'], '^', color='#d62728', ms=6, label='ACT ($\\tau$=0,1)')
    a.set_ylim(*yl[l]); a.set_title(LN[l], fontsize=8); a.set_xlabel('FLOPs relatif', fontsize=7); a.tick_params(labelsize=6.5); a.grid(True, ls='--', alpha=0.35)
ax[0].set_ylabel('Akurasi', fontsize=7); h, lb = ax[0].get_legend_handles_labels(); fig.legend(h, lb, loc='lower center', ncol=3, fontsize=6.5, frameon=False, bbox_to_anchor=(0.5, -0.04))
commafy(fig); plt.tight_layout(rect=[0, 0.1, 1, 1]); plt.savefig('img/fig2.png', dpi=300, bbox_inches='tight'); plt.close()
fig, ax = plt.subplots(1, 2, figsize=(6.6, 2.5)); col = {'ID': '#1f77b4', 'EN': '#2ca02c', 'MS': '#d62728'}; x = np.arange(1, 13)
for l in L:
    ax[0].plot(x, S['head'][l]['EE']['acc'], 'o-', ms=3, color=col[l], label=f'{LN[l]}, bobot linear'); ax[0].plot(x, S['head'][l]['EEu']['acc'], 'x--', ms=3.5, lw=0.9, color=col[l], label=f'{LN[l]}, bobot seragam')
    ax[1].plot(x, S['head'][l]['EE']['U'], 'o-', ms=3, color=col[l], label=LN[l])
ax[0].set_ylabel('Akurasi kepala keluar', fontsize=7); ax[1].set_ylabel('Rerata entropi ternormalisasi (bobot linear)', fontsize=7)
for a, t in zip(ax, ['(a) Akurasi kepala keluar per lapisan', '(b) Ketidakpastian prediksi per lapisan']): a.set_xlabel('Lapisan', fontsize=7); a.set_title(t, fontsize=8); a.tick_params(labelsize=6.5); a.grid(True, ls='--', alpha=0.35); a.set_xticks(x)
ax[0].set_ylim(0.2, 0.95); ax[0].legend(fontsize=5.5, frameon=False, ncol=2, loc='lower right'); commafy(fig); plt.tight_layout(); plt.savefig('img/fig1.png', dpi=300, bbox_inches='tight'); plt.close()
print('Selesai: stats_j1.json, img/fig1.png, img/fig2.png')
