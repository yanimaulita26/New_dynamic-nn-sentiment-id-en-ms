"""Analisis hasil Eksperimen E1 (Jurnal 1): titik operasi tetap, perbandingan dengan model statis dangkal,
kualitas head per layer, perilaku ACT, dan gambar.  Pemakaian:  python analyze_e1.py results_dynamic_A.json latensi.csv summary_dinamis.csv
Membutuhkan core.py (fungsi murni yang sama dengan notebook) di folder yang sama. Keluaran: stats_j1.json, img/fig1.png, img/fig2.png"""
import sys, os, json
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from core import *
RES, LAT, SUM = (sys.argv[1:4] + ['results_dynamic_A.json', 'latensi.csv', 'summary_dinamis.csv'][len(sys.argv[1:4]):])
R = json.load(open(RES)); L = ['ID', 'EN', 'MS']; seeds = sorted([s for s in R['ID'].keys()], key=int); rng = np.random.default_rng(0)
LN = {'ID': 'Indonesian', 'EN': 'English', 'MS': 'Malay'}; y = {l: np.array(R['_meta'][l]['y']) for l in L}; S = {}
pcs = lambda l, key, cn: [np.array(R[l][s][key]['configs'][cn]['preds']) for s in seeds]
def stat(l, key, cn, ref=('S12', 'S12')):
    n = len(y[l]); idx = rng.integers(0, n, size=(4000, n))
    dv = np.mean([(a == y[l]).astype(float) - (b == y[l]).astype(float) for a, b in zip(pcs(l, key, cn), pcs(l, *ref))], axis=0); b = dv[idx].mean(1) * 100
    cf = [R[l][s][key]['configs'][cn] for s in seeds]
    return dict(flops=float(np.mean([c['rel_flops'] for c in cf])), acc=float(np.mean([c['acc'] for c in cf])), acc_sd=float(np.std([c['acc'] for c in cf], ddof=1)),
                d=float(dv.mean() * 100), lo=float(np.percentile(b, 2.5)), hi=float(np.percentile(b, 97.5)),
                rneg=float(np.mean([c['rneg'] for c in cf])), pneg=float(np.mean([c['pneg'] for c in cf])))
PT = {'S12': ('S12', 'S12'), 'S4': ('S4', 'S4'), 'S6': ('S6', 'S6'), 'S8': ('S8', 'S8'), 'E03': ('EE', 'EEent_0.3'), 'E08': ('EE', 'EEent_0.8'), 'E01': ('EE', 'EEent_0.1'),
      'A01': ('ACT_0.1', 'ACT_0.1'), 'A10': ('ACT_1.0', 'ACT_1.0'), 'P3': ('EE', 'EEpat_3'), 'P5': ('EE', 'EEpat_5')}
S['pt'] = {l: {k: stat(l, *v) for k, v in PT.items()} for l in L}
S['vs'] = {l: {'E08_S6': stat(l, 'EE', 'EEent_0.8', ref=('S6', 'S6')), 'E03_S8': stat(l, 'EE', 'EEent_0.3', ref=('S8', 'S8'))} for l in L}
S['head'] = {l: {'acc': np.mean([R[l][s]['EE']['diag']['acc_per_layer'] for s in seeds], axis=0).tolist(), 'U': np.mean([R[l][s]['EE']['diag']['U_mean_per_layer'] for s in seeds], axis=0).tolist()} for l in L}
S['act'] = {}
for l in L:
    for k in ['ACT_0.1', 'ACT_1.0']:
        h = np.mean([R[l][s][k]['diag']['N_hist'] for s in seeds], axis=0); N = np.arange(1, 13); S['act'][f'{l}|{k}'] = {'mean_layers': float(np.sum(h * N) / h.sum()), 'hist': (h / h.sum() * 100).tolist()}
lat = pd.read_csv(LAT); S['lat'] = {f"{r.bahasa}|{r.konfigurasi}": {'ms': r.latensi_ms, 'sd': (None if pd.isna(r.SD) else r.SD), 'ratio': r.rasio_vs_S12, 'flops': r.FLOPs_rel, 'n': int(r.n_seed)} for r in lat.itertuples()}
S['summary'] = pd.read_csv(SUM).to_dict('records'); S['agree_min'] = float(lat['kesepakatan_truncating_vs_offline'].min())
os.makedirs('img', exist_ok=True); json.dump(S, open('stats_j1.json', 'w'), indent=1)
fig, ax = plt.subplots(1, 3, figsize=(7.2, 2.7)); yl = {'ID': (0.82, 0.915), 'EN': (0.84, 0.93), 'MS': (0.725, 0.815)}
for a, l in zip(ax, L):
    def agg(prefix):
        pts = {}
        for s in seeds:
            for cn, c in R[l][s]['EE']['configs'].items():
                if cn.startswith(prefix): pts.setdefault(cn, []).append((c['rel_flops'], c['acc']))
        return sorted([(np.mean([p[0] for p in v]), np.mean([p[1] for p in v]), cn) for cn, v in pts.items()])
    e = [p for p in agg('EEent') if p[2] != 'EEent_1.0']; pa = agg('EEpat')
    a.plot([p[0] for p in e], [p[1] for p in e], 'o-', ms=3, lw=1.2, color='#1f77b4', label='Early exit (entropy)'); a.plot([p[0] for p in pa], [p[1] for p in pa], 's--', ms=3, lw=1.0, color='#2ca02c', label='Early exit (patience)')
    for k in ['S4', 'S6', 'S8', 'S12']: p = S['pt'][l][k]; a.plot(p['flops'], p['acc'], 'D', color='black', ms=4); a.annotate(k, (p['flops'], p['acc']), fontsize=6, xytext=(2, 3), textcoords='offset points')
    p = S['pt'][l]['A01']; a.plot(p['flops'], p['acc'], '^', color='#d62728', ms=6, label='ACT ($\\tau$=0.1)')
    a.set_ylim(*yl[l]); a.set_title(LN[l], fontsize=8); a.set_xlabel('Relative FLOPs', fontsize=7); a.tick_params(labelsize=6.5); a.grid(True, ls='--', alpha=0.35)
ax[0].set_ylabel('Accuracy', fontsize=7); h, lb = ax[0].get_legend_handles_labels(); fig.legend(h, lb, loc='lower center', ncol=3, fontsize=6.5, frameon=False, bbox_to_anchor=(0.5, -0.02))
plt.tight_layout(rect=[0, 0.08, 1, 1]); plt.savefig('img/fig1.png', dpi=300, bbox_inches='tight'); plt.close()
fig, ax = plt.subplots(1, 2, figsize=(6.6, 2.4)); col = {'ID': '#1f77b4', 'EN': '#2ca02c', 'MS': '#d62728'}; x = np.arange(1, 13)
for l in L: ax[0].plot(x, S['head'][l]['acc'], 'o-', ms=3, color=col[l], label=LN[l]); ax[1].plot(x, S['head'][l]['U'], 'o-', ms=3, color=col[l], label=LN[l])
ax[0].set_ylabel('Accuracy of exit head', fontsize=7); ax[1].set_ylabel('Mean normalized entropy', fontsize=7)
for a, t in zip(ax, ['(a) Exit-head accuracy by layer', '(b) Prediction uncertainty by layer']): a.set_xlabel('Layer', fontsize=7); a.set_title(t, fontsize=8); a.tick_params(labelsize=6.5); a.grid(True, ls='--', alpha=0.35); a.set_xticks(x)
ax[0].legend(fontsize=6.5, frameon=False); plt.tight_layout(); plt.savefig('img/fig2.png', dpi=300, bbox_inches='tight'); plt.close()
print('Selesai: stats_j1.json, img/fig1.png, img/fig2.png')
for l in L: print(l, {k: (round(1 - S['pt'][l][k]['flops'], 3), round(S['pt'][l][k]['d'], 2)) for k in ['E03', 'E08', 'S8', 'S6']})
