# Dynamic neural networks for multilingual sentiment classification (Indonesian, English, Malay)

Code, raw results and analysis for **Journal 1**: *Verified Early Exit and Adaptive Computation Time for Multilingual Sentiment Classification in Indonesian, English, and Malay* (Y. Maulita, A. Afnan, K. Muchtar, R. Roslidar). Part of a doctoral dissertation at Universitas Syiah Kuala.

> Status: manuscript in preparation. Add the citation and DOI here after publication.

## What this repository contains

Multi-exit **multilingual BERT** (`bert-base-multilingual-cased`) for binary sentiment classification, trained jointly on Indonesian, English and Malay and evaluated per language. Compared methods:

- entropy-based and patience-based **early exit**,
- **Adaptive Computation Time (ACT)** with a differentiable ponder cost,
- **fixed shallower baselines** (first 4, 6, 8 layers) and the full 12-layer model.

Early exit and ACT **really truncate the computation** (layers after the exit are not executed). Predictions and layers used are checked against a full-computation simulation (agreement 100% in every timed configuration). Operating points are selected on validation data and judged on test data with paired bootstrap intervals (test items; seeds and items jointly), five seeds (42, 123, 2024, 7, 99).

## Layout

```
journal1/
  notebooks/
    Eksperimen_OpsiA_J1_DynamicNN.ipynb   E1: seeds 42, 123, 2024 (GPU)
    Eksperimen_E1b_Seed_Ablasi.ipynb      E1b: seeds 7, 99 + uniform exit-loss-weight ablation (continues E1)
  src/
    core.py                  pure-numpy functions (FLOPs, entropy, exit rules, selection, summary)
    analyze_e1b.py           5-seed statistics and figures (used in the paper)
    analyze_e1.py            same analysis for the first 3 seeds
    analyze_e1b_figuras_id.py  same statistics, Indonesian figure labels
    check_ponder_gradient.py check that the ACT ponder cost reaches the halting units
  results/
    raw/                     results_dynamic_A.json (5 seeds), latensi.csv, summary_dinamis.csv, ablasi_bobot.csv
    e1_3seed/                the first 3-seed run, kept unchanged for transparency
    stats_j1.json            every statistic reported in the paper
    figures/{en,id}/         fig1 (accuracy and entropy per exit head), fig2 (accuracy vs relative FLOPs)
  run_analysis.sh            regenerates stats_j1.json and the figures from raw/
data/README.md               where the datasets come from (not redistributed)
requirements.txt
```

## Reproduce the numbers (no GPU needed)

```bash
pip install -r requirements.txt
sh journal1/run_analysis.sh
```

The script is deterministic (fixed random generator). The output is identical to the committed `results/stats_j1.json`.

## Re-run the experiments (GPU needed)

1. Open `notebooks/Eksperimen_OpsiA_J1_DynamicNN.ipynb` in Google Colab with a T4 GPU and run it top to bottom. It downloads the datasets (see `data/README.md`) and writes `results_dynamic_A.json`, `latensi.csv`, `summary_dinamis.csv`. Success criteria are fixed in the configuration cell before any result is seen; do not change them afterwards.
2. Run `notebooks/Eksperimen_E1b_Seed_Ablasi.ipynb` to add seeds 7 and 99 and the uniform-weight ablation.
3. Run `journal1/run_analysis.sh` on the new files.

Latency was measured at batch size 1 on an NVIDIA Tesla T4 (16 GB) in Google Colab, so absolute milliseconds depend on the hardware. Package versions are not pinned in this release; record `torch` and `transformers` versions when you re-run.

## Main results (five seeds, test sets)

| | Indonesian | English | Malay |
|---|---|---|---|
| Full model accuracy | 0.8961 | 0.9066 | 0.7956 |
| Early exit, entropy, θ = 0.3: computation saved | 46% | 47% | 41% |
| Accuracy change vs full model (points) | −0.13 | +0.46 | +0.24 |
| 95% lower bound, seeds and items (points) | −2.6 | −1.3 | −1.4 |
| Fixed 8 layers: computation saved | 33% | 33% | 33% |

Pre-registered criterion: met for Malay and English, not for Indonesian (validation set of 76 texts is too coarse for the one-point tolerance). Early exit is not faster than the fixed 8-layer model in wall-clock time; ACT collapses to a near-constant depth in the tested configurations; patience-based exit collapses because the heads of layers 1–4 predict a single class.

## Licence

Code: MIT (see `LICENSE`). Datasets keep their own licences (see `data/README.md`).

---

## Ringkasan (Bahasa Indonesia)

Repositori ini memuat kode eksperimen, hasil mentah, dan skrip analisis Jurnal 1 (keluar dini dan Adaptive Computation Time pada mBERT untuk klasifikasi sentimen bahasa Indonesia, Inggris, dan Melayu). Untuk mereproduksi seluruh angka dan gambar tanpa GPU, jalankan `pip install -r requirements.txt` lalu `sh journal1/run_analysis.sh`. Untuk menjalankan ulang eksperimen, buka kedua notebook di `journal1/notebooks/` di Google Colab (GPU T4) sesuai urutan di atas. Data tidak disertakan; lihat `data/README.md`.
